/* Jordan Rivera portfolio: shared and page-specific scripts */

// ---------- Dark / light mode (all pages) ----------
const root = document.documentElement;
const themeToggle = document.getElementById("themeToggle");

function applyTheme(theme) {
  root.setAttribute("data-bs-theme", theme);
  if (themeToggle) {
    themeToggle.innerHTML = theme === "dark"
      ? '<i class="bi bi-sun"></i>'
      : '<i class="bi bi-moon-stars"></i>';
  }
}

let savedTheme = null;
try { savedTheme = localStorage.getItem("theme"); } catch (e) { /* storage unavailable */ }
applyTheme(savedTheme || (window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"));

if (themeToggle) {
  themeToggle.addEventListener("click", () => {
    const next = root.getAttribute("data-bs-theme") === "dark" ? "light" : "dark";
    applyTheme(next);
    try { localStorage.setItem("theme", next); } catch (e) { /* ignore */ }
  });
}

// ---------- Back-to-top button (all pages) ----------
const backToTop = document.getElementById("backToTop");
if (backToTop) {
  window.addEventListener("scroll", () => { backToTop.hidden = window.scrollY < 400; });
  backToTop.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));
}

// ---------- Home: greeting based on time of day ----------
const greeting = document.getElementById("greeting");
if (greeting) {
  const hour = new Date().getHours();
  const word = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";
  greeting.textContent = word + ", and welcome.";
}

// ---------- Skills: detail panel ----------
const skillBadges = document.querySelectorAll(".skill-badge");
const skillDetailText = document.getElementById("skillDetailText");
skillBadges.forEach(badge => {
  badge.addEventListener("click", () => {
    skillBadges.forEach(b => b.classList.remove("selected"));
    badge.classList.add("selected");
    skillDetailText.textContent = badge.dataset.skill;
  });
});

// ---------- Projects: load JSON, build cards, filter ----------
const projectGrid = document.getElementById("projectGrid");

if (projectGrid) {
  const filterBar = document.getElementById("filterBar");
  const modal = new bootstrap.Modal(document.getElementById("projectModal"));
  let projects = [];

  fetch("data/projects.json")
    .then(response => {
      if (!response.ok) throw new Error("HTTP " + response.status);
      return response.json();
    })
    .then(data => {
      projects = data;
      buildFilters();
      showProjects("All");
    })
    .catch(error => {
      projectGrid.innerHTML =
        '<div class="alert alert-warning">Projects could not be loaded. ' +
        'Run this site through a local web server (such as Live Server) instead of opening the file directly.</div>';
      console.error(error);
    });

  function buildFilters() {
    const categories = ["All", ...new Set(projects.map(p => p.category))];
    categories.forEach((cat, index) => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "btn filter-btn" + (index === 0 ? " active" : "");
      btn.textContent = cat;
      btn.setAttribute("aria-pressed", index === 0 ? "true" : "false");
      btn.addEventListener("click", () => {
        filterBar.querySelectorAll(".filter-btn").forEach(b => {
          b.classList.remove("active");
          b.setAttribute("aria-pressed", "false");
        });
        btn.classList.add("active");
        btn.setAttribute("aria-pressed", "true");
        showProjects(cat);
      });
      filterBar.appendChild(btn);
    });
  }

  function showProjects(category) {
    projectGrid.innerHTML = "";
    const visible = projects.filter(p => category === "All" || p.category === category);

    visible.forEach(project => {
      const col = document.createElement("div");
      col.className = "col-md-6 col-lg-4";

      const card = document.createElement("div");
      card.className = "card project-card h-100";
      card.tabIndex = 0;
      card.setAttribute("role", "button");
      card.setAttribute("aria-label", "View details for " + project.title);

      const body = document.createElement("div");
      body.className = "card-body d-flex flex-column";

      const badge = document.createElement("span");
      badge.className = "badge cat-badge align-self-start mb-2";
      badge.textContent = project.category;

      const title = document.createElement("h2");
      title.className = "h5";
      title.textContent = project.title;

      const desc = document.createElement("p");
      desc.textContent = project.description;

      const tech = document.createElement("div");
      tech.className = "d-flex flex-wrap gap-2 mt-auto";
      project.technologies.forEach(t => tech.appendChild(makeTechBadge(t)));

      body.append(badge, title, desc, tech);
      card.appendChild(body);
      col.appendChild(card);
      projectGrid.appendChild(col);

      const open = () => openModal(project);
      card.addEventListener("click", open);
      card.addEventListener("keydown", e => {
        if (e.key === "Enter" || e.key === " ") { e.preventDefault(); open(); }
      });
    });
  }

  function makeTechBadge(text) {
    const span = document.createElement("span");
    span.className = "badge tech-badge";
    span.textContent = text;
    return span;
  }

  function openModal(project) {
    document.getElementById("projectModalTitle").textContent = project.title;
    document.getElementById("projectModalCategory").textContent = project.category;
    document.getElementById("projectModalDescription").textContent = project.description;
    document.getElementById("projectModalHighlights").textContent = project.highlights || "";
    const techBox = document.getElementById("projectModalTech");
    techBox.innerHTML = "";
    project.technologies.forEach(t => techBox.appendChild(makeTechBadge(t)));
    modal.show();
  }
}
